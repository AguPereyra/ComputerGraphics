const normalize = (a) => {
  throw new Error('Not implemented')
}

const cross = (a, b) => {
  throw new Error('Not implemented')
}

const normals = (a, b, c) => {
  throw new Error('Not implemented')
}

module.exports = {
  normalize,
  cross,
  normals
}
