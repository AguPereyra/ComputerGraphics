require('./math.spec')
require('./sample/classic/bar.spec')

require('./mat4/index.spec')
require('./vec3/index.spec')

require('./color/classic/hex.spec')
require('./color/classic/hsl.spec')
require('./color/classic/rgb.spec')
require('./color/classic/style.spec')
