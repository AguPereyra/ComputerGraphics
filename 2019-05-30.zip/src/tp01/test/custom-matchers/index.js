const toBeEqualish = require('./to-be-equalish')

module.exports = {
  toBeEqualish
}
