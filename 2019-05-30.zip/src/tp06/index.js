console.log('tp06')

const obj = require('../models/cube.obj')

console.log(obj)
