module.exports = {
  "extends": "standard",
  "env": {
    "browser": true
  },
  "rules": {
    "comma-dangle": "off"
  }
}
